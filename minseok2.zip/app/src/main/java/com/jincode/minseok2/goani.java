package com.jincode.minseok2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class goani extends AppCompatActivity {

    Button gocal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goani);

        gocal = findViewById(R.id.gocal);
        gocal.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), gocal.class);
                startActivity(intent);
            }
        });
    }
}